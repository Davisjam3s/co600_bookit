$(document).on("scroll", function() 
{

	if($(document).scrollTop()>1) 
	{
		$("header").removeClass("large").addClass("small");
	} 
	else 
	{
		$("header").removeClass("small").addClass("large");
	}
	});

function CatalogNav() 
{
	$(".mainnav").hide();
	$(".booknav").hide();
	$(".invnav").hide();
	$(".catnav").show();
}
function BookingNav() 
{
	$(".mainnav").hide();
	$(".booknav").show();
	$(".invnav").hide();
	$(".catnav").hide();
}
function InventoryNav() 
{
	$(".mainnav").hide();
	$(".booknav").hide();
	$(".invnav").show();
	$(".catnav").hide();
}