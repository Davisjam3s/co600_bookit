$(document).ready(function() // when the document is ready
    {
    	$(".addi").click(function() // when has this div been pressed?
            {
            	$(".mainnav").show(); // show the orginal menu
            	$(".invnav").hide(); // hede the menu we just used
            	$("p").hide(); // for the love of god, remember to hide this
            	$(".holder").show(); // show the hidden div
            	$(".holder").load("ajax/Pages/Inventory/add_inventory.php"); // fill the hidden div
            });
    });

