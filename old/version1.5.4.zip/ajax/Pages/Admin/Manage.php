<?php
echo "<p>Admin Controls -Manage</p>";
echo "Very useful echo.";
?>