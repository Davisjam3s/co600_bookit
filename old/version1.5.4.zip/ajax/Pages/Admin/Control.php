<?php
echo "<p>Admin Controls</p>";
echo "Very useful echo.";
?>