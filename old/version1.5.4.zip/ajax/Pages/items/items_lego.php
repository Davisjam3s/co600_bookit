
<?php 
$x = 1; 
echo "<p>Lego</p>";
while($x <= 10) {
    echo "<div class='catalog_item'><div class='item_overlay'>$x </div> <img src='images/items/lego.jpg' height='160' width='170'> </div>";
    $x++;
} 
?>