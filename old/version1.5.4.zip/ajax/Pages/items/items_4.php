
<?php 
$x = 1; 
echo "<p>Type 5</p>";
while($x <= 15) {
    echo "<div class='catalog_item'><div class='item_overlay'>$x </div> <img src='images/items/books.jpg' height='160' width='170'> </div>";
    $x++;
} 
?>