

<?php 
$x = 1; 
echo "<p>Type 4</p>";
while($x <= 9) {
    echo "<div class='catalog_item'><div class='item_overlay'>$x </div> <img src='images/items/lego.jpg' height='160' width='170'> </div>";
    $x++;
} 
?>