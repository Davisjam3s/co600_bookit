<?php // connect the server and display if done
$servername = "dragon.kent.ac.uk";
$username = "m04_bookit";
$password = "b*asiis";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
?>
<?php // display the name user name
    if(isset ($_SERVER['REMOTE_USER']))
    	{
            $user=$_SERVER['REMOTE_USER'];
               if ($user == 'jd601'|| $user == 'jd603')
               		{
                 		echo " $user ";  // put this on the page
               		}
        }				
?>
<?php 
	if(isset ($_SERVER['REMOTE_MAIL']))
		{
			$mail=$_SERVER['REMOTE_MAIL'];
			echo $mail;
		}
		else
		{
			echo "Obv not correct, try again";
		}
?>
