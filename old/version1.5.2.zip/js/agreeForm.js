$(document).ready(function()
{
    $(".back").click(function()
      {
          $(".1").show();
          $(".2").hide();
          $(".3").hide();
          $(".4").hide();
      });
  });
 function AgreeForm() 
{
  $(".menu_container_background").show();
  $(".menu_container").show();
}