<!DOCTYPE html>
<html>
<head>
	<title>Book IT</title>
	<!--Styles-->
	<link rel="stylesheet" type="text/css" href="css/PageMainStyle.css"/>
  <link rel="stylesheet" type="text/css" href="css/cat_items.css"/>
  <link rel="stylesheet" type="text/css" href="css/agreeForm.css"/>
	<!--end of styles-->
	<!--Scripts-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="ajax/Scripts/Load_items.js"></script>
	<script type="text/javascript" src="js/header.js"></script>
  <script type="text/javascript" src="js/agreeForm.js"></script>

	<!--end of scripts-->
</head>
<body>

  <div class="menu_container_background"></div>
  <div class="menu_container">
    <div class="agreement">
      <p class="agreetitle">Agreement</p>
      nah fam i wont break nothin, no no no
      <div>
      <Form class="formAgree">
      <input type="checkbox" name="yes" value="agree"> checking this box and pressing agree signs away your rights
      <input type="submit" name="Agree" value="Decline">
        <input type="submit" name="Agree" value="Agree">
      </Form>
      </div>
    </div>

  </div>

<header class="large"> <!--set to large instantly, this gives the bigger header-->
  <div class="container"> <!--this is the container within the header-->
    <nav> <!--this is for the navagation area-->
    <a href="index.php"><img src="images/uni_logo.png"></a> <!--this is for the logo-->
      <ul class="1"> <!--this is the orginal navagation menu-->
          <li><a href="#" onclick="AgreeForm() ">Agree</a></li>
        	<li><a href="#" onclick="CatalogNav()">Catalog</a></li>
        	<li><a href="#" onclick="BookingNav()">My Bookings</a></li>
        	<li><a href="#" onclick="ContactNav()">Contact us</a></li>
        	<li><a href="#"><?php require 'php/user_info.php';?></a></li> <!--who is the user?-->
        		<?php 
					if(isset ($_SERVER['REMOTE_USER']))
						{
							$user=$_SERVER['REMOTE_USER'];
								if ($user == 'jd601') 
								{
									echo "<li><a href='#'>Admin</a></li>";
								}
						}				
				?> <!--quick test to test user types-->
        
       </ul><!--end of orginal header-->

       <ul class="ul2 2"> <!--this is for the catalog items, set to hidden, wont be displayed until activated by user-->
        	<li><a href="#" class="all">All</a></li>
        	<li><a href="#" class="lego">Lego</a></li>
        	<li><a href="#" class="pi">Pi's</a></li>
        	<li><a href="#" class="t4">Type 4</a></li>
        	<li><a href="#" class="t5">Type 5</a></li>
          <li><a href="#" class="back">Back</a></li> <!--helps navagate the menu-->
        </ul> <!--end of catalog-->
        <ul class="ul3 3"> <!--start of bookings menu-->
        	<li><a href="#">Current Bookings</a></li>
        	<li><a href="#">Past Bookings</a></li>
           <li><a href="#" class="back">Back</a></li>
        </ul> <!--end of bookings menu-->
        <ul class="ul4 4"><!--start of contact us-->
        	<li><a href="#">Message Form</a></li>
        	<li><a href="#">Email Us</a></li>
           <li><a href="#" class="back">Back</a></li>
        </ul> <!--end of the contact us menu-->

    </nav> <!--end of the navagation menu-->
  </div> <!--end of the contanier-->
</header> <!--end of the header-->
<section class="stretch"> <!--things should be placed within here to work-->
  <p class="mainp">Welcome to bookIT</p> <!--title of the page-->
  <div class="holder">Nothing to display</div> <!--hidden div which will contain working ajax when needed-->

</section> <!--end of section which should contain things within the page.-->	
</body>
</html>