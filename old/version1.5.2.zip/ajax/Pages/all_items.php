<?php 
$x = 1; 

echo "<p>all items</p>";
while($x <= 52) {
    echo "<div class='catalog_item'>$x</div>";
    $x++;
} 

?>