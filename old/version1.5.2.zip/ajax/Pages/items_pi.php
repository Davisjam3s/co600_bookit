<?php 
$x = 1; 
echo "<p>Pi</p>";
while($x <= 10) {
    echo "<div class='catalog_item'> <img src='images/trump.jpg' height='160' width='170'> </div>";
    $x++;
} 
?>