<?php 
$x = 1; 
echo "<p>type 5</p>";
while($x <= 15) {
    echo "<div class='catalog_item'>$x</div>";
    $x++;
} 
?>