<?php 
$x = 1; 
echo "<p>type 4</p>";
while($x <= 9) {
    echo "<div class='catalog_item'>$x</div>";
    $x++;
} 
?>