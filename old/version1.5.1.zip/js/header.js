$(document).on("scroll", function() 
{

	if($(document).scrollTop()>1) 
	{
		$("header").removeClass("large").addClass("small");
	} 
	else 
	{
		$("header").removeClass("small").addClass("large");
	}
	});

function CatalogNav() 
{
	$(".1").hide();
	$(".3").hide();
	$(".4").hide();
	$(".2").show();
}
function BookingNav() 
{
	$(".1").hide();
	$(".2").hide();
	$(".4").hide();
	$(".3").show();
}
function ContactNav() 
{
	$(".1").hide();
	$(".2").hide();
	$(".3").hide();
	$(".4").show();
}