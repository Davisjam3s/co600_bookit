$(document).ready(function()
    {
    	$(".addi").click(function()
            {
            	$(".1").show();
            	$(".4").hide();
            	$(".holder").show();
            	$(".holder").load("ajax/Pages/Inventory/add_inventory.php");
            });
    });

