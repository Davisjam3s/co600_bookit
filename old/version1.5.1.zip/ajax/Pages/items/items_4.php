
<?php 
$x = 1; 
echo "<p>Type 5</p>";
while($x <= 15) {
    echo "<div class='catalog_item'><div class='item_overlay'>$x </div>$x</div>";
    $x++;
} 
?>