

<?php 
$x = 1; 
echo "<p>Type 4</p>";
while($x <= 9) {
    echo "<div class='catalog_item'><div class='item_overlay'>$x </div>$x</div>";
    $x++;
} 
?>